import flet as ft
from .estilos import crear_boton, crear_pagina, NEGRO
from .medios import crear_bloque_texto_con_nota


def crear(page, navegar):
    contenido = [
        crear_bloque_texto_con_nota(
            "Para ti, Mormochito",
            "No siempre encuentro la manera exacta de decir lo que siento, por eso quise escribirlo y dejarlo en estas páginas.",
            "recuerdo_10.jpeg",
            "Una imagen que acompaña estas palabras",
            lado="derecha",
            numero="01  ·  ESTA CARTA ES PARA TI",
        ),
        crear_bloque_texto_con_nota(
            "Lo que me gusta de conocerte",
            "Me gusta poder descubrir tus pequeños detalles y encontrar motivos para sonreír cuando pienso en ti. No necesito que todo sea perfecto; para mí lo bonito está en la sinceridad, en el cariño y en las ganas de compartir.",
            "foto3.jpeg",
            "Un recuerdo muy especial",
            lado="izquierda",
            numero="02  ·  LO QUE SIENTO",
        ),
        crear_bloque_texto_con_nota(
            "Lo que quiero construir",
            "No quiero prometerte una historia sin dificultades. Quiero ofrecerte respeto, honestidad, atención y la disposición de construir algo bonito, paso a paso.",
            "fotos1.jpeg",
            "Un instante para guardar",
            lado="derecha",
            numero="03  ·  PASO A PASO",
        ),
        ft.Container(
            content=ft.Text(
                "Gracias por ser alguien tan especial. Esta carta es pequeña, pero está hecha con un cariño enorme.\n\nCon mucho cariño, ♥",
                size=14,
                color=NEGRO,
                italic=True,
                text_align=ft.TextAlign.CENTER,
            ),
            bgcolor="#FFF1F0",
            padding=15,
            border_radius=16,
            width=340,
        ),
    ]
    botones = [
        crear_boton("HAY ALGO QUE QUIERO PREGUNTARTE", lambda e: navegar("pregunta")),
        crear_boton("VOLVER A LOS RECUERDOS", lambda e: navegar("recuerdos"), principal=False),
    ]
    return crear_pagina(
        "Capítulo 03",
        "Una carta para ti",
        "Hay cosas que merecen decirse con calma y desde el corazón.",
        contenido,
        botones,
        icono="✉",
    )
