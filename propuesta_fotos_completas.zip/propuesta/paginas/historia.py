import flet as ft
from .estilos import crear_boton, crear_pagina, NEGRO, DORADO
from .medios import crear_bloque_texto_con_nota, crear_bloque_con_media, crear_nota_video


def crear(page, navegar):
    contenido = [
        ft.Text(
            "Hay historias que se escriben con fechas; la nuestra quiero recordarla por los momentos y las emociones.",
            size=13,
            color=NEGRO,
            text_align=ft.TextAlign.CENTER,
        ),
        crear_bloque_texto_con_nota(
            "El comienzo",
            "A veces las historias más bonitas comienzan sin hacer mucho ruido. Lo especial es todo lo que poco a poco se va descubriendo.",
            "recuerdo_03.jpeg",
            "Las primeras páginas",
            lado="derecha",
            numero="01  ·  PRIMERAS PÁGINAS",
        ),
        ft.Text("⋮  ✧  ⋮", size=17, color=DORADO),
        crear_bloque_texto_con_nota(
            "Conocerte",
            "Entre palabras, sonrisas y pequeños detalles, he podido descubrir muchas razones para apreciarte cada día más.",
            "recuerdo_04.jpeg",
            "Un momento que guardo",
            lado="izquierda",
            numero="02  ·  MOMENTOS",
        ),
        crear_bloque_texto_con_nota(
            "Lo que admiro de ti",
            "Hay cosas de tu forma de ser que te hacen única. Quiero que sepas que valoro esos detalles, incluso los que quizá tú no notas.",
            "recuerdo_05.jpeg",
            "Un detalle que me encanta",
            lado="derecha",
            numero="03  ·  LO ESPECIAL",
        ),
        crear_bloque_con_media(
            "Lo que viene",
            "No sé exactamente qué nos espera, pero me ilusiona la idea de seguir compartiendo momentos, aprendiendo y creando recuerdos bonitos.",
            crear_nota_video(2, navegar, volver_a="historia"),
            lado="izquierda",
            numero="04  ·  LO QUE FALTA POR ESCRIBIR",
        ),
        crear_bloque_texto_con_nota(
            "Una página que quiero conservar",
            "Y entre tantas cosas pequeñas, también hay imágenes que me recuerdan lo bonito que es coincidir contigo.",
            "recuerdo_06.jpeg",
            "Una sonrisa para guardar",
            lado="derecha",
            numero="05  ·  OTRO RECUERDO",
        ),
        ft.Text(
            "Esta historia no está terminada. Todavía quedan muchas páginas por escribir. ♥",
            size=13,
            italic=True,
            color=NEGRO,
            text_align=ft.TextAlign.CENTER,
        ),
    ]
    botones = [
        crear_boton("VER NUESTROS RECUERDOS", lambda e: navegar("recuerdos")),
        crear_boton("VOLVER A LA DEDICATORIA", lambda e: navegar("dedicatoria"), principal=False),
    ]
    return crear_pagina(
        "Capítulo 01",
        "Nuestra historia",
        "No se trata de contar cada fecha, sino de recordar lo bonito de irnos conociendo.",
        contenido,
        botones,
        icono="♡",
    )
