import flet as ft
from .estilos import (
    BEIGE, BLANCO, DORADO, NEGRO, VINO, crear_boton, crear_marco_foto,
)
from .medios import crear_bloque_con_media, crear_nota_video


def _animar_marco(e):
    e.control.rotate = 0.025 if e.data == "true" else -0.018
    e.control.update()


def crear(page, navegar):
    foto = crear_marco_foto("fotos/recuerdo_01.jpeg", ancho=230, alto=409, rotacion=-0.018)
    foto.on_hover = _animar_marco

    contenido = ft.Column(
        controls=[
            ft.Row(
                controls=[
                    ft.Text("✧", size=19, color=DORADO),
                    ft.Text("UNA EDICIÓN ESPECIAL", size=11, color=VINO, weight=ft.FontWeight.BOLD),
                    ft.Text("✧", size=19, color=DORADO),
                ],
                alignment=ft.MainAxisAlignment.CENTER,
                spacing=7,
            ),
            ft.Text("♡", size=52, color=VINO),
            ft.Text("UN PEQUEÑO LIBRO", size=11, color=DORADO, weight=ft.FontWeight.BOLD),
            ft.Text("Para mi", size=25, color=NEGRO, text_align=ft.TextAlign.CENTER),
            ft.Text("Mormochito", size=38, color=VINO, weight=ft.FontWeight.BOLD,
                    text_align=ft.TextAlign.CENTER),
            ft.Text("❀  ✧  ❀", size=20, color="#D89BAA"),
            ft.Container(content=foto, padding=4),
            crear_bloque_con_media(
                "Un pequeño lugar para nosotros",
                "Guardé palabras, recuerdos y un instante en movimiento para que puedas volver a ellos cuando quieras.",
                crear_nota_video(0, navegar, volver_a="portada"),
                lado="derecha",
                numero="✧  UNA HISTORIA HECHA CON CARIÑO  ✧",
            ),
            crear_boton("ABRIR NUESTRO LIBRO  ♥", lambda e: navegar("dedicatoria")),
            ft.Text("Con mucho cariño, para ti.", size=13, color=VINO, italic=True),
            ft.Text("✦  ♡  ✦", size=15, color=DORADO),
        ],
        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        alignment=ft.MainAxisAlignment.CENTER,
        spacing=8,
        scroll=ft.ScrollMode.AUTO,
    )
    return ft.Container(
        content=contenido,
        bgcolor=BEIGE,
        padding=18,
        border_radius=25,
        width=390,
        height=790,
        alignment=ft.Alignment(0, 0),
        shadow=ft.BoxShadow(blur_radius=16, color="#2A000000", offset=ft.Offset(1, 5)),
    )
