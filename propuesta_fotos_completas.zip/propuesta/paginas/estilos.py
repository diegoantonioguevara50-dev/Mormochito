import flet as ft

# Paleta romántica: rosa empolvado, crema, vino y pequeños acentos dorados.
ROSA = "#E8AAB8"
ROSA_CLARO = "#FCE8ED"
ROSA_SUAVE = "#F7DDE4"
BEIGE = "#F5EBDD"
CREMA = "#FFF9F2"
VINO = "#8B2635"
DORADO = "#C49A54"
BLANCO = "#FFFFFF"
NEGRO = "#30252A"
GRIS = "#806C70"


def _animar_hover(e):
    """Pequeño efecto de escala al pasar el cursor sobre una tarjeta o botón."""
    e.control.scale = 1.035 if e.data == "true" else 1.0
    e.control.update()


def crear_boton(texto, accion, principal=True):
    """Botón redondeado con un efecto suave al pasar el cursor."""
    boton = ft.Button(
        content=ft.Text(
            texto,
            color=BLANCO if principal else VINO,
            weight=ft.FontWeight.BOLD,
            size=12,
            text_align=ft.TextAlign.CENTER,
        ),
        bgcolor=VINO if principal else ROSA_SUAVE,
        on_click=accion,
        width=315,
        height=48,
    )
    return ft.Container(
        content=boton,
        width=325,
        alignment=ft.Alignment(0, 0),
        scale=1.0,
        animate_scale=ft.Animation(220, ft.AnimationCurve.EASE_OUT),
        on_hover=_animar_hover,
    )


def crear_tarjeta(titulo, descripcion, numero=None):
    """Tarjeta de recuerdo con sombra y una elevación visual al pasar el cursor."""
    controles = [
        ft.Text("✧  ♡  ✧", size=15, color=DORADO),
    ]
    if numero:
        controles.append(
            ft.Container(
                content=ft.Text(numero, size=12, color=VINO, weight=ft.FontWeight.BOLD),
                bgcolor=ROSA_CLARO,
                padding=ft.Padding.symmetric(horizontal=13, vertical=6),
                border_radius=18,
            )
        )
    controles.extend([
        ft.Text(
            titulo,
            size=18,
            color=VINO,
            weight=ft.FontWeight.BOLD,
            text_align=ft.TextAlign.CENTER,
        ),
        ft.Text(
            descripcion,
            size=14,
            color=NEGRO,
            text_align=ft.TextAlign.CENTER,
        ),
        ft.Text("♥", size=16, color=ROSA),
    ])
    return ft.Container(
        content=ft.Column(
            controls=controles,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=9,
        ),
        bgcolor=BLANCO,
        padding=17,
        border_radius=18,
        width=325,
        shadow=ft.BoxShadow(
            blur_radius=12,
            color="#26000000",
            offset=ft.Offset(1, 4),
        ),
        scale=1.0,
        animate_scale=ft.Animation(230, ft.AnimationCurve.EASE_OUT),
        on_hover=_animar_hover,
    )


def crear_marco_foto(imagen, ancho=250, alto=180, rotacion=0):
    """Marco tipo fotografía impresa, con una ligera inclinación decorativa."""
    return ft.Container(
        content=ft.Image(
            src=imagen,
            width=ancho,
            height=alto,
            fit=ft.BoxFit.CONTAIN,
        ),
        bgcolor=BLANCO,
        padding=9,
        border_radius=14,
        rotate=rotacion,
        animate_rotation=ft.Animation(280, ft.AnimationCurve.EASE_OUT),
        shadow=ft.BoxShadow(
            blur_radius=13,
            color="#30000000",
            offset=ft.Offset(1, 5),
        ),
    )


def crear_pagina(capitulo, titulo, subtitulo, contenido, botones, icono="♡"):
    """Marco común de las páginas interiores, con decoración y scroll vertical."""
    controles = [
        ft.Row(
            controls=[
                ft.Text("✧", size=17, color=DORADO),
                ft.Text("HECHO CON CARIÑO", size=10, color=GRIS, weight=ft.FontWeight.BOLD),
                ft.Text("✧", size=17, color=DORADO),
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            spacing=9,
        ),
        ft.Container(
            content=ft.Text(
                capitulo.upper(),
                size=10,
                color=VINO,
                weight=ft.FontWeight.BOLD,
                text_align=ft.TextAlign.CENTER,
            ),
            bgcolor=ROSA_CLARO,
            padding=ft.Padding.symmetric(horizontal=15, vertical=7),
            border_radius=20,
        ),
        ft.Container(
            content=ft.Text(icono, size=38, color=VINO),
            bgcolor="#FFF0F3",
            width=68,
            height=68,
            border_radius=34,
            alignment=ft.Alignment(0, 0),
            scale=1.0,
            animate_scale=ft.Animation(450, ft.AnimationCurve.EASE_OUT),
            on_hover=_animar_hover,
        ),
        ft.Text(
            titulo,
            size=25,
            color=VINO,
            weight=ft.FontWeight.BOLD,
            text_align=ft.TextAlign.CENTER,
        ),
        ft.Text(
            subtitulo,
            size=13,
            color=NEGRO,
            text_align=ft.TextAlign.CENTER,
        ),
        ft.Row(
            controls=[
                ft.Container(width=48, height=1, bgcolor="#E8C9D0"),
                ft.Text("♥", size=13, color=ROSA),
                ft.Container(width=48, height=1, bgcolor="#E8C9D0"),
            ],
            alignment=ft.MainAxisAlignment.CENTER,
            spacing=8,
        ),
    ]
    controles.extend(contenido)
    controles.append(ft.Container(height=4))
    controles.extend(botones)
    controles.extend([
        ft.Container(height=5),
        ft.Text("✧  Hecho especialmente para ti  ✧", size=11, color=VINO, italic=True),
        ft.Text("♡", size=17, color=ROSA),
    ])

    return ft.Container(
        content=ft.Column(
            controls=controles,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=13,
            scroll=ft.ScrollMode.AUTO,
        ),
        bgcolor=CREMA,
        padding=19,
        border_radius=24,
        width=390,
        height=790,
        alignment=ft.Alignment(0, 0),
        shadow=ft.BoxShadow(
            blur_radius=15,
            color="#24000000",
            offset=ft.Offset(0, 5),
        ),
    )
