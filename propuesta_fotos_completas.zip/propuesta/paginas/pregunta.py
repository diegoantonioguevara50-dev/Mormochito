import flet as ft
from .estilos import BLANCO, NEGRO, ROSA_CLARO, VINO, DORADO, crear_boton, crear_pagina
from .medios import crear_bloque_texto_con_nota


def crear(page, navegar):
    contenido = [
        ft.Text("Llegaste a la última página…", size=15, color=NEGRO, text_align=ft.TextAlign.CENTER),
        crear_bloque_texto_con_nota(
            "Quiero seguir creando recuerdos contigo",
            "Quiero compartir más momentos, cuidarnos, reír y descubrir juntos lo que puede venir.",
            "recuerdo_01.jpeg",
            "Un recuerdo que abre otro capítulo",
            lado="derecha",
            numero="✧  UN DESEO PARA EL FUTURO  ✧",
        ),
        ft.Container(
            content=ft.Column(
                controls=[
                    ft.Text("✧  ♥  ✧", size=21, color=DORADO),
                    ft.Text(
                        "Y ahora sí…",
                        size=14,
                        color=DORADO,
                        italic=True,
                        text_align=ft.TextAlign.CENTER,
                    ),
                    ft.Text(
                        "¿QUIERES SER MI NOVIA?",
                        size=24,
                        color=VINO,
                        weight=ft.FontWeight.BOLD,
                        text_align=ft.TextAlign.CENTER,
                    ),
                    ft.Text(
                        "No tienes que responder por compromiso. Lo más importante es que puedas decirme lo que realmente sientes.",
                        size=13,
                        color=NEGRO,
                        text_align=ft.TextAlign.CENTER,
                    ),
                    ft.Text("♥  ✧  ♡  ✧  ♥", size=21, color=VINO),
                ],
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=11,
            ),
            bgcolor=BLANCO,
            padding=18,
            border_radius=18,
            width=315,
            shadow=ft.BoxShadow(blur_radius=11, color="#26000000", offset=ft.Offset(1, 4)),
        ),
    ]
    botones = [
        crear_boton("SÍ, QUIERO  ♥", lambda e: navegar("respuesta_si")),
        crear_boton("QUIERO PENSARLO CON CALMA", lambda e: navegar("respuesta_tiempo"), principal=False),
        crear_boton("VOLVER A LA CARTA", lambda e: navegar("cartas"), principal=False),
    ]
    return crear_pagina(
        "La última página",
        "Tengo algo que preguntarte…",
        "Preparé este momento con mucho cariño.",
        contenido,
        botones,
        icono="♥",
    )
