import flet as ft
from .estilos import crear_boton, crear_pagina
from .medios import crear_bloque_texto_con_nota, crear_bloque_con_media, crear_nota_video


def crear(page, navegar):
    contenido = [
        crear_bloque_texto_con_nota(
            "Para ti, que haces especiales los pequeños momentos",
            "Quería hacer algo diferente para ti: un pequeño libro que pudieras recorrer con calma y que guardara un poquito de lo que significas para mí.",
            "recuerdo_02.jpeg",
            "Un momento para sonreír",
            lado="derecha",
            numero="01  ·  PARA TI",
        ),
        crear_bloque_con_media(
            "Lo que a veces cuesta decir",
            "Tal vez no existan palabras perfectas para expresar lo que siento, pero sí puedo intentar demostrarte, con detalles, lo importante que eres.",
            crear_nota_video(1, navegar, volver_a="dedicatoria"),
            lado="izquierda",
            numero="02  ·  UN RECUERDO EN MOVIMIENTO",
        ),
        crear_bloque_texto_con_nota(
            "Cada página tiene un poquito de ti",
            "Ojalá al verla puedas sonreír y sentir todo el cariño con el que la hice. Quise que encontraras pequeños recuerdos entre estas palabras.",
            "Foto2.jpeg",
            "Entre risas y recuerdos",
            lado="derecha",
            numero="03  ·  CON MUCHO CARIÑO",
        ),
    ]
    botones = [
        crear_boton("SEGUIR CON NUESTRA HISTORIA", lambda e: navegar("historia")),
        crear_boton("VOLVER A LA PORTADA", lambda e: navegar("portada"), principal=False),
    ]
    return crear_pagina(
        "Una página solo para ti",
        "Antes de comenzar…",
        "Quiero dedicarte estas primeras palabras.",
        contenido,
        botones,
        icono="♥",
    )
