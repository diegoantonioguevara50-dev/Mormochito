import flet as ft
from .estilos import BLANCO, NEGRO, VINO, DORADO, crear_boton, crear_pagina
from .medios import crear_bloque_texto_con_nota


def crear(page, navegar, respuesta="si"):
    if respuesta == "si":
        titulo = "¡Me haces muy feliz!"
        subtitulo = "Gracias por darme la oportunidad de comenzar esta etapa contigo."
        mensaje = (
            "Quiero que lo que venga esté lleno de respeto, confianza, comunicación y muchos "
            "momentos bonitos. Gracias por decir que sí. ♥"
        )
        icono = "♥"
        detalle = "✧  ¡UN NUEVO CAPÍTULO COMIENZA!  ✧"
    else:
        titulo = "Gracias por ser sincera"
        subtitulo = "No hay prisa y no tienes que responder por compromiso."
        mensaje = (
            "Lo importante para mí es que te sientas tranquila y puedas decidir con libertad. "
            "Gracias por tomarte el tiempo de leer este pequeño libro."
        )
        icono = "♡"
        detalle = "GRACIAS POR LEER MI HISTORIA"

    contenido = [
        ft.Text(detalle, size=11, color=DORADO, weight=ft.FontWeight.BOLD, text_align=ft.TextAlign.CENTER),
        crear_bloque_texto_con_nota(
            titulo,
            mensaje,
            "foto3.jpeg",
            "Un recuerdo que guardo con cariño",
            lado="derecha",
            numero="♡  UN MOMENTO PARA RECORDAR  ♡",
        ),
        ft.Text("Este recuerdo queda guardado con cariño.", size=13, color=VINO, italic=True,
                text_align=ft.TextAlign.CENTER),
    ]
    botones = [
        crear_boton("VOLVER A LA PORTADA", lambda e: navegar("portada")),
    ]
    return crear_pagina(
        "Un último mensaje",
        titulo,
        subtitulo,
        contenido,
        botones,
        icono=icono,
    )
