import flet as ft
from .estilos import NEGRO, DORADO, crear_boton, crear_pagina
from .medios import crear_bloque_texto_con_nota, crear_bloque_con_media, crear_nota_video


def crear(page, navegar):
    contenido = [
        ft.Text(
            "No quise poner todos los recuerdos juntos. Preferí dejar pequeñas notitas entre las palabras, como si fueran páginas de un álbum de verdad.",
            size=13,
            color=NEGRO,
            italic=True,
            text_align=ft.TextAlign.CENTER,
        ),
        crear_bloque_texto_con_nota(
            "Hay momentos que merecen quedarse",
            "A veces basta una fotografía para volver a una sensación, una sonrisa o un ratito que uno quisiera guardar un poquito más.",
            "recuerdo_07.jpeg",
            "Un ratito bonito",
            lado="izquierda",
            numero="01  ·  PARA VOLVER A MIRAR",
        ),
        crear_bloque_con_media(
            "Y otros recuerdos se mueven",
            "Por eso también guardé este pequeño video. Puedes abrir la notita cuando quieras volver a verlo.",
            crear_nota_video(3, navegar, volver_a="recuerdos"),
            lado="derecha",
            numero="02  ·  DALE PLAY AL RECUERDO",
        ),
        crear_bloque_texto_con_nota(
            "Pequeñas cosas, grandes sonrisas",
            "No todos los recuerdos necesitan una gran historia. Algunos se vuelven especiales simplemente porque forman parte de nuestros días.",
            "recuerdo_08.jpeg",
            "Momentos compartidos",
            lado="izquierda",
            numero="03  ·  PEQUEÑOS DETALLES",
        ),
        crear_bloque_texto_con_nota(
            "Una colección de instantes",
            "Estas imágenes son pequeñas piezas de algo que me gusta recordar. Quería que aparecieran aquí, entre las palabras, y no todas en una sola página.",
            "recuerdo_09.jpeg",
            "Una ternura para guardar",
            lado="derecha",
            numero="04  ·  NUESTRO ÁLBUM",
        ),
        ft.Text(
            "Cada notita guarda algo distinto. Gracias por ser parte de estos recuerdos. ♥",
            size=13,
            color=NEGRO,
            italic=True,
            text_align=ft.TextAlign.CENTER,
        ),
    ]
    botones = [
        crear_boton("CONTINUAR A LA CARTA", lambda e: navegar("cartas")),
        crear_boton("VOLVER A NUESTRA HISTORIA", lambda e: navegar("historia"), principal=False),
    ]
    return crear_pagina(
        "Capítulo 02",
        "Nuestros recuerdos",
        "Fotografías y videos escondidos entre las páginas.",
        contenido,
        botones,
        icono="♡",
    )
