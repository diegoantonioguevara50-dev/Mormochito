import flet as ft

ROSA_CLARO = "#FCE8ED"
ROSA_SUAVE = "#F7DDE4"
VINO = "#8B2635"
DORADO = "#C49A54"
BLANCO = "#FFFFFF"
NEGRO = "#30252A"

FOTOS = [
    ("recuerdo_01.jpeg", "Un día para recordar"),
    ("recuerdo_02.jpeg", "Una sonrisa bonita"),
    ("recuerdo_03.jpeg", "Un instante especial"),
    ("recuerdo_04.jpeg", "Una página de nuestra historia"),
    ("recuerdo_05.jpeg", "Un detalle que se queda"),
    ("recuerdo_06.jpeg", "Una sonrisa para guardar"),
    ("recuerdo_07.jpeg", "Un ratito bonito"),
    ("recuerdo_08.jpeg", "Momentos compartidos"),
    ("recuerdo_09.jpeg", "Una ternura para recordar"),
    ("recuerdo_10.jpeg", "Una mirada especial"),
]

FOTOS_EXTRA = {
    "foto3.jpeg": "Un recuerdo muy especial",
    "fotos1.jpeg": "Un instante para guardar",
    "Foto2.jpeg": "Un momento entre sonrisas",
}

VIDEOS = [
    ("clip_01.mp4", "clip_01.jpg", "Un recuerdo en movimiento"),
    ("clip_02.mp4", "clip_02.jpg", "Ese instante otra vez"),
    ("clip_03.mp4", "clip_03.jpg", "Un momento para volver"),
    ("clip_04.mp4", "clip_04.jpg", "Un pedacito de nuestra historia"),
]


def _animar_nota(e):
    entrando = e.data == "true"
    e.control.scale = 1.045 if entrando else 1.0
    e.control.update()


def crear_nota_foto_archivo(archivo, texto, ancho=104, alto_imagen=92, rotacion=0.0):
    """Nota Polaroid para una foto; admite tanto las fotos numeradas como las extra."""
    return ft.Container(
        content=ft.Column(
            controls=[
                ft.Image(
                    src=f"fotos/{archivo}",
                    width=ancho - 14,
                    height=alto_imagen,
                    fit=ft.BoxFit.CONTAIN,
                ),
                ft.Text(
                    texto,
                    size=9 if ancho < 125 else 10,
                    color=VINO,
                    italic=True,
                    text_align=ft.TextAlign.CENTER,
                    max_lines=2,
                ),
                ft.Text("♡", size=10, color="#D69AAA"),
            ],
            spacing=3,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        ),
        width=ancho,
        bgcolor=BLANCO,
        padding=7,
        border_radius=7,
        rotate=rotacion,
        animate_rotation=ft.Animation(240, ft.AnimationCurve.EASE_OUT),
        animate_scale=ft.Animation(220, ft.AnimationCurve.EASE_OUT),
        shadow=ft.BoxShadow(blur_radius=9, color="#26000000", offset=ft.Offset(1, 4)),
        on_hover=_animar_nota,
    )


def crear_nota_foto(indice, ancho=104, alto_imagen=92, rotacion=0.0):
    archivo, texto = FOTOS[indice]
    return crear_nota_foto_archivo(archivo, texto, ancho, alto_imagen, rotacion)


def crear_nota_video(indice, navegar, volver_a="portada", ancho=104, alto_imagen=92):
    """Nota pequeña y clicable que abre el reproductor del video seleccionado."""
    archivo, poster, texto = VIDEOS[indice]
    return ft.Container(
        content=ft.Column(
            controls=[
                ft.Stack(
                    controls=[
                        ft.Image(
                            src=f"assets/videos/previews/{poster}",
                            width=ancho - 14,
                            height=alto_imagen,
                            fit=ft.BoxFit.CONTAIN,
                        ),
                        ft.Container(
                            content=ft.Text("▶", size=24, color=BLANCO, weight=ft.FontWeight.BOLD),
                            alignment=ft.Alignment(0, 0),
                            width=ancho - 14,
                            height=alto_imagen,
                            bgcolor="#55000000",
                        ),
                    ],
                    width=ancho - 14,
                    height=alto_imagen,
                ),
                ft.Text(
                    texto,
                    size=9 if ancho < 125 else 10,
                    color=VINO,
                    italic=True,
                    text_align=ft.TextAlign.CENTER,
                    max_lines=2,
                ),
                ft.Text(
                    "▶ VER VIDEO",
                    size=8 if ancho < 125 else 9,
                    color=DORADO,
                    weight=ft.FontWeight.BOLD,
                ),
            ],
            spacing=3,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
        ),
        width=ancho,
        bgcolor=BLANCO,
        padding=7,
        border_radius=7,
        rotate=0.018 if indice % 2 else -0.018,
        animate_rotation=ft.Animation(240, ft.AnimationCurve.EASE_OUT),
        animate_scale=ft.Animation(220, ft.AnimationCurve.EASE_OUT),
        shadow=ft.BoxShadow(blur_radius=9, color="#26000000", offset=ft.Offset(1, 4)),
        on_hover=_animar_nota,
        on_click=lambda e: navegar(f"video_{indice}_{volver_a}"),
        tooltip="Toca para reproducir este recuerdo",
    )


def crear_bloque_con_media(titulo, descripcion, nota, lado="derecha", numero=None):
    """Acompaña cada texto con una notita al lado, alternando su posición por página."""
    textos = []
    if numero:
        textos.append(
            ft.Text(numero, size=9, color=DORADO, weight=ft.FontWeight.BOLD)
        )
    textos.extend([
        ft.Text(
            titulo,
            size=15,
            color=VINO,
            weight=ft.FontWeight.BOLD,
            text_align=ft.TextAlign.CENTER,
        ),
        ft.Text(
            descripcion,
            size=12,
            color=NEGRO,
            text_align=ft.TextAlign.CENTER,
        ),
        ft.Text("♥", size=13, color="#D69AAA"),
    ])

    tarjeta_texto = ft.Container(
        content=ft.Column(
            controls=textos,
            spacing=7,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            alignment=ft.MainAxisAlignment.CENTER,
        ),
        bgcolor=BLANCO,
        padding=12,
        border_radius=16,
        width=226,
        shadow=ft.BoxShadow(blur_radius=9, color="#1F000000", offset=ft.Offset(1, 3)),
    )

    controles = [nota, tarjeta_texto] if lado == "izquierda" else [tarjeta_texto, nota]
    return ft.Container(
        content=ft.Row(
            controls=controles,
            alignment=ft.MainAxisAlignment.CENTER,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=8,
            wrap=True,
        ),
        width=355,
        padding=3,
    )


def crear_bloque_texto_con_nota(titulo, descripcion, archivo, pie, lado="derecha", numero=None):
    nota = crear_nota_foto_archivo(
        archivo,
        pie,
        ancho=104,
        alto_imagen=92,
        rotacion=-0.025 if lado == "derecha" else 0.025,
    )
    return crear_bloque_con_media(titulo, descripcion, nota, lado=lado, numero=numero)
