from pathlib import Path

import flet as ft

try:
    import flet_video as ftv
except ImportError:  # El álbum puede abrir aunque el complemento no esté instalado.
    ftv = None

from .estilos import (
    BLANCO, CREMA, DORADO, NEGRO, ROSA_CLARO, VINO,
    crear_boton, crear_pagina,
)
from .medios import VIDEOS

BASE_DIR = Path(__file__).resolve().parent.parent
VIDEO_DIR = BASE_DIR / "assets" / "videos"


def crear(page, navegar, indice=0, volver_a="portada"):
    indice = max(0, min(int(indice), len(VIDEOS) - 1))
    archivo, poster, titulo = VIDEOS[indice]
    video_path = (VIDEO_DIR / archivo).resolve()

    estado_video = ft.Text(
        "Preparando este recuerdo... ♡",
        size=11,
        color=VINO,
        italic=True,
        text_align=ft.TextAlign.CENTER,
    )

    if ftv is None:
        reproductor = ft.Container(
            content=ft.Text(
                "Para reproducir los videos instala flet-video:\n"
                "python -m pip install flet-video",
                color=VINO,
                text_align=ft.TextAlign.CENTER,
            ),
            bgcolor=ROSA_CLARO,
            padding=20,
            border_radius=15,
            width=310,
        )
    elif not video_path.is_file():
        estado_video.value = "No se encontró el archivo de este video."
        reproductor = ft.Container(
            content=ft.Column(
                controls=[
                    ft.Text("No encuentro este recuerdo", color=VINO, weight=ft.FontWeight.BOLD),
                    ft.Text(str(video_path), size=10, color=NEGRO, text_align=ft.TextAlign.CENTER),
                ],
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                spacing=8,
            ),
            bgcolor=ROSA_CLARO,
            padding=20,
            border_radius=15,
            width=310,
        )
    else:
        # VideoMedia necesita una URI reproducible por media_kit.
        # La ruta absoluta file:/// evita depender de la carpeta desde la que se ejecuta PowerShell.
        video_uri = video_path.as_uri()

        def video_cargado(e):
            estado_video.value = "♡ Este recuerdo ya está listo. Presiona reproducir. ♡"
            estado_video.color = VINO
            estado_video.update()
            print(f"[VIDEO] Cargado correctamente: {video_path}")

        def video_error(e):
            detalle = str(getattr(e, "data", "") or "El reproductor no pudo abrir el archivo.")
            estado_video.value = "No se pudo abrir este video. Revisa el detalle en PowerShell."
            estado_video.color = "#B3261E"
            estado_video.update()
            print(f"[VIDEO ERROR] Archivo: {video_path}")
            print(f"[VIDEO ERROR] Detalle: {detalle}")

        print(f"[VIDEO] Intentando abrir: {video_uri}")
        reproductor = ft.Container(
            content=ftv.Video(
                playlist=[ftv.VideoMedia(video_uri)],
                autoplay=False,
                width=300,
                height=440,
                fit=ft.BoxFit.CONTAIN,
                on_load=video_cargado,
                on_error=video_error,
            ),
            bgcolor="#24191C",
            padding=6,
            border_radius=16,
            width=312,
            shadow=ft.BoxShadow(blur_radius=12, color="#30000000", offset=ft.Offset(1, 4)),
        )

    contenido = [
        ft.Container(
            content=ft.Text("▶  UN RECUERDO EN MOVIMIENTO  ♥", size=10, color=DORADO,
                            weight=ft.FontWeight.BOLD, text_align=ft.TextAlign.CENTER),
            bgcolor=ROSA_CLARO,
            padding=10,
            border_radius=20,
        ),
        ft.Text(titulo, size=18, color=VINO, weight=ft.FontWeight.BOLD,
                text_align=ft.TextAlign.CENTER),
        reproductor,
        estado_video,
        ft.Text(
            "Dale play cuando quieras volver a este pedacito de nuestra historia.",
            size=13, color=NEGRO, italic=True, text_align=ft.TextAlign.CENTER,
        ),
        ft.Text("♡  ✧  ♡", size=18, color="#D69AAA"),
    ]
    botones = [
        crear_boton("VOLVER A LAS NOTITAS", lambda e: navegar(volver_a)),
        crear_boton("IR A NUESTROS RECUERDOS", lambda e: navegar("recuerdos"), principal=False),
    ]
    return crear_pagina(
        "Un video para recordar",
        "Mira este momento…",
        "Los recuerdos también se pueden volver a vivir.",
        contenido,
        botones,
        icono="▶",
    )
