import flet as ft
from pathlib import Path

import flet_audio as fta

from paginas import portada, dedicatoria, historia, recuerdos, cartas, pregunta, respuesta, videos
from paginas.estilos import ROSA_CLARO, CREMA, VINO

BASE_DIR = Path(__file__).resolve().parent
RUTA_MUSICA = BASE_DIR / "assets" / "musica" / "cancion.mp3"


def main(page: ft.Page):
    page.title = "Para mi Mormochito"
    page.bgcolor = ROSA_CLARO
    page.padding = 8
    page.window.width = 430
    page.window.height = 850
    page.theme_mode = ft.ThemeMode.LIGHT

    paginas = {
        "portada": portada.crear,
        "dedicatoria": dedicatoria.crear,
        "historia": historia.crear,
        "recuerdos": recuerdos.crear,
        "cartas": cartas.crear,
        "pregunta": pregunta.crear,
    }

    switcher = ft.AnimatedSwitcher(
        content=ft.Container(),
        transition=ft.AnimatedSwitcherTransition.FADE,
        duration=620,
        reverse_duration=420,
        switch_in_curve=ft.AnimationCurve.EASE_OUT,
        switch_out_curve=ft.AnimationCurve.EASE_IN,
        expand=True,
    )

    def mostrar_pagina(nombre):
        if nombre == "respuesta_si":
            vista = respuesta.crear(page, mostrar_pagina, "si")
        elif nombre == "respuesta_tiempo":
            vista = respuesta.crear(page, mostrar_pagina, "tiempo")
        elif nombre.startswith("video_"):
            partes = nombre.split("_", 2)
            indice = int(partes[1]) if len(partes) > 1 else 0
            volver_a = partes[2] if len(partes) > 2 else "portada"
            vista = videos.crear(page, mostrar_pagina, indice, volver_a)
        else:
            constructor = paginas.get(nombre, portada.crear)
            vista = constructor(page, mostrar_pagina)

        switcher.content = ft.Container(
            content=vista,
            alignment=ft.Alignment(0, 0),
            expand=True,
        )
        switcher.update()

    # Música de fondo: se reproduce al abrir el álbum y vuelve a comenzar
    # al terminar. El botón flotante permite pausarla o reanudarla.
    musica = fta.Audio(
        src="assets/musica/cancion.mp3",
        autoplay=RUTA_MUSICA.is_file(),
        volume=0.32,
        release_mode=fta.ReleaseMode.LOOP,
        on_loaded=lambda _: print("[MÚSICA] Audio cargado correctamente."),
    )
    page.services.append(musica)
    musica_activa = RUTA_MUSICA.is_file()

    boton_musica = ft.IconButton(
        icon=ft.Icons.PAUSE,
        icon_color=VINO,
        icon_size=22,
        tooltip="Pausar música",
    )

    async def alternar_musica(e):
        nonlocal musica_activa
        if not RUTA_MUSICA.is_file():
            print(f"[MÚSICA ERROR] No se encontró el archivo: {RUTA_MUSICA}")
            boton_musica.tooltip = "No se encontró la música"
            boton_musica.update()
            return

        try:
            if musica_activa:
                await musica.pause()
                musica_activa = False
                boton_musica.icon = ft.Icons.PLAY_ARROW
                boton_musica.tooltip = "Reanudar música"
            else:
                await musica.resume()
                musica_activa = True
                boton_musica.icon = ft.Icons.PAUSE
                boton_musica.tooltip = "Pausar música"
            boton_musica.update()
        except Exception as error:
            print(f"[MÚSICA ERROR] No se pudo controlar la reproducción: {error}")
            boton_musica.tooltip = "No se pudo controlar la música; revisa PowerShell"
            boton_musica.update()

    boton_musica.on_click = alternar_musica

    zona_principal = ft.Container(
        content=switcher,
        alignment=ft.Alignment(0, 0),
        expand=True,
    )
    control_flotante = ft.Container(
        content=boton_musica,
        bgcolor=CREMA,
        border_radius=24,
        padding=2,
        right=12,
        top=8,
        shadow=ft.BoxShadow(blur_radius=8, color="#26000000", offset=ft.Offset(1, 3)),
    )

    page.add(
        ft.Stack(
            controls=[zona_principal, control_flotante],
            expand=True,
        )
    )

    mostrar_pagina("portada")


if __name__ == "__main__":
    ft.run(main, assets_dir=str(BASE_DIR))
